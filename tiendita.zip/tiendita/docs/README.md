# Marketplace Local Colaborativo

Estructura base del proyecto.